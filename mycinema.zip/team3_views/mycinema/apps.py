from django.apps import AppConfig


class MycinemaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mycinema'
