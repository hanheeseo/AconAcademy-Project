from django.shortcuts import render
from django.http.response import HttpResponse, JsonResponse

# Create your views here.
def createSeat(request):
    for i in range(1, 21):
        print('A' + str(i), end=' ')
    
    return 'a'

