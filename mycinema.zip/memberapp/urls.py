from django.urls import path
from memberapp import views

urlpatterns = [
    path('list', views.ListFunc),
    path('insert', views.InsertFunc),
    path('idcheck', views.IdcheckFunc),
    path('zipcheck', views.ZipcheckFunc),
    path('zipcheckok', views.ZipcheckOkFunc),
]