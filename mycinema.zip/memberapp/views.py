from django.shortcuts import render
import MySQLdb
from memberapp.models import MemTable
from django.http.response import HttpResponseRedirect

config = {
    'host':'127.0.0.1',
    'user':'root',
    'password':'123',
    'database':'dbmember',
    'port':3306,
    'charset':'utf8',
    'use_unicode':True
}

# Create your views here.
def MainFunc(request):
    return render(request, 'main.html')

def ListFunc(request):
    datas = MemTable.objects.all()
    return render(request, 'list.html', {'members':datas})

def InsertFunc(request):
    if request.method == 'GET':
        return render(request, 'insert.html')
    elif request.method == 'POST':
        #ORM
        MemTable(
            memid = request.POST.get('memid'),
            passwd = request.POST.get('passwd'),
            name = request.POST.get('name'),
            email = request.POST.get('email'),
            phone = request.POST.get('phone'),
            zipcode = request.POST.get('zipcode'),
            address = request.POST.get('address'),
            job = request.POST.get('job'),
        ).save()
        return HttpResponseRedirect('/member/list')
        
        #SQL
        
    else:
        return render(request, 'error.html') 

def IdcheckFunc(request):
    memid = request.GET.get('memid')
    #print(memid)
    isRegister = False   # memid 등록여부 판단용
    try:
        #ORM
        #data = MemTable.objects.get(memid = memid)
        
        #SQL
        sql = "select * from memberapp_memtable where memid='{0}'".format(memid)
        conn = MySQLdb.connect(**config)
        cursor = conn.cursor()
        cursor.execute(sql)
        data = cursor.fetchone()
        
        if data != None:
            isRegister = True
    except Exception as e:
        print('err :', e)
    finally:
        cursor.close()
        conn.close()
    
    return render(request, 'idcheck.html', {'memid':isRegister}) 


def ZipcheckFunc(request):
    chk = request.GET.get('check')
    return render(request, 'zipcheck.html', {'check':chk})

def ZipcheckOkFunc(request):
    area3 = request.POST.get('area3')
    print('area3 : ', area3)
    chk = request.POST.get('check')  #n
    try:
        #SQL
        sql = "select * from memberapp_ziptab where area3 like '{0}%'".format(area3)
        conn = MySQLdb.connect(**config)
        cursor = conn.cursor()
        cursor.execute(sql)
        datas = cursor.fetchall()
        print(datas)
        
    except Exception as e:
        print('ZipcheckOkFunc err :', e)
    finally:
        cursor.close()
        conn.close()
    
    return render(request, 'zipcheck.html', {'datas':datas, "check":chk})
    




